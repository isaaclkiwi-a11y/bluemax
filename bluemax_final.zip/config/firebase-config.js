
// Paste your Firebase web config here and enable Realtime Database rules.
window.FIREBASE_CONFIG = {};
